import React from 'react'


function Astronauta() {
  return (
    <div className='astronauta'>
    
   </div>
  )
}

export default Astronauta