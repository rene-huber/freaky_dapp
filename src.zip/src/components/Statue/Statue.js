import marmol from "../../img/marmol.png"

function Statue() {
  return (
    <div>
    <img src={marmol} alt='algo'/>
    </div>
  )
}

export default Statue