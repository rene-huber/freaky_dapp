import plasma from "../../img/plasma.gif"

function Corona() {
  return (
    <div className="corona">
        {/* <img src={plasma} alt={""} /> */}
    </div>
  )
}

export default Corona