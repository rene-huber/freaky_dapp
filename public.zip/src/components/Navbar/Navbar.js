import Logo from "../../img/logo.png"
import "./Navbar.css"


function Navbar() {
  return (
    <div className="logo">
    <img src={Logo} alt={"f"} />
  </div>
  )
}

export default Navbar