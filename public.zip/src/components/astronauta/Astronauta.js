import React from 'react'
import TexRotarYZ from '../textoRotar2/TexRotarYZ'


function Astronauta() {
  return (
    <div className='astronauta'>
    <TexRotarYZ />
   </div>
  )
}

export default Astronauta